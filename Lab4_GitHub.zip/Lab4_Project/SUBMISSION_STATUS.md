# Checklist đối chiếu Lab 4

| Yêu cầu đề bài | File/minh chứng | Trạng thái |
|---|---|---|
| A. Normalize; inventory ≥15 unit, 2 candidates/unit; metadata; histogram duration/RMS | `Lab04.py`, `lab4_data/units/`, `lab4_data/metadata.csv`, `figures/01*`, `figures/02*` | Đã chạy với 16 từ × 2 WAV eSpeak tổng hợp; không phải giọng người thật |
| B. Baseline concatenation; `raw_concat.wav`; waveform/spectrogram và biên nối | `audio_output/raw_concat.wav`, `figures/03_spectrogram_before_after.png`, `figures/04_boundary_waveforms.png` | Đã chạy |
| C. Target cost, join cost, DP; cross-fade 0/5/15/30 ms | `audio_output/best_concat.wav`, `audio_output/join_costs.csv`, `audio_output/crossfade_*.wav`, `figures/05_unit_selection_costs.png` | Đã chạy |
| D. F0, duration/time-stretch, pitch shift ±2 semitone, source–filter | `lab4_data/hmm_demo/moi_01_f0_track.csv`, `audio_output/duration_*.wav`, `audio_output/pitch_*.wav`, `figures/06_f0_contour.png` | Đã chạy |
| E. HMM state sequence, F0/spectral/duration trajectory, audio | `lab4_data/hmm_demo/`, `audio_output/hmm_tts.wav`, `figures/07*`, `figures/08*`, `figures/09*` | Đã chạy HMM demo 5-state left-to-right per word, Gaussian emissions; resynthesis bằng mel inversion + Griffin-Lim. Không phải hệ HMM production/MLPG |
| F. Neural TTS pretrained; mel-spectrogram; latency | `lab4_data/neural_tts_backend.py`, `prepare_neural_model.py`, `run_neural_tts.py`, `requirements-neural.txt` | Có code và hướng dẫn; chưa inference vì checkpoint không tải được trong môi trường đóng gói không có Internet. Chưa có neural WAV/latency |
| G. Intelligibility, naturalness, continuity, latency; MOS/listening test ≥3 câu | `audio_output/three_sentence_test.csv`, `audio_output/ratings_template.csv` | Có 3 câu test và mẫu đánh giá; cần người nghe chấm và điền dữ liệu thật |
| Báo cáo 5–8 trang | `Bao_cao_Lab4.docx` | Báo cáo 8 trang; điền thông tin sinh viên và cập nhật kết quả F/G sau khi chạy |

## Các việc còn cần làm trước khi xác nhận nộp cuối

1. Điền họ tên, mã sinh viên, lớp, giảng viên trên báo cáo.
2. Nếu giảng viên yêu cầu giọng người thật, thay inventory eSpeak bằng bản thu theo yêu cầu Fs=16 kHz, mono và tạo lại metadata/kết quả.
3. Trên máy có Internet, cài `requirements-neural.txt`, chạy `prepare_neural_model.py`, sau đó `run_neural_tts.py` để tạo Neural TTS audio, mel-spectrogram và latency.
4. Tổ chức listening test cho ít nhất 3 câu, điền `audio_output/ratings_template.csv` bằng điểm người nghe thật và cập nhật báo cáo.
5. Kiểm tra hướng dẫn riêng của giảng viên về mức độ yêu cầu HMM. Backend hiện tại là Gaussian HMM demo nhỏ, không dùng Baum–Welch/MLPG đầy đủ.

Không điền số liệu người nghe giả định và không đánh dấu F/G hoàn tất trước khi các phép chạy/đánh giá tương ứng thực sự được thực hiện.
