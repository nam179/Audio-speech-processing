from pathlib import Path
import time
import numpy as np
import soundfile as sf
import torch
from transformers import AutoTokenizer, VitsModel

MODEL_ID = "facebook/mms-tts-vie"
MODEL_DIR = Path(__file__).resolve().parent / "pretrained_model" / "facebook-mms-tts-vie"

_tokenizer = None
_model = None
_device = "cuda" if torch.cuda.is_available() else "cpu"


def load_model(local_files_only=True):
    global _tokenizer, _model
    if _tokenizer is None or _model is None:
        source = str(MODEL_DIR) if (MODEL_DIR / "config.json").exists() else MODEL_ID
        _tokenizer = AutoTokenizer.from_pretrained(
            source,
            local_files_only=local_files_only
        )
        _model = VitsModel.from_pretrained(
            source,
            local_files_only=local_files_only
        ).to(_device)
        _model.eval()
    return _tokenizer, _model


def synthesize(text: str, output_path=None, local_files_only=True):
    tokenizer, model = load_model(local_files_only=local_files_only)
    inputs = tokenizer(text, return_tensors="pt")
    inputs = {key: value.to(_device) for key, value in inputs.items()}

    start = time.perf_counter()
    with torch.no_grad():
        waveform = model(**inputs).waveform[0].detach().cpu().numpy()
    latency = time.perf_counter() - start

    sample_rate = int(model.config.sampling_rate)
    waveform = np.asarray(waveform, dtype=np.float32)
    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(output_path), waveform, sample_rate, subtype="PCM_16")

    return waveform, sample_rate, {"latency_seconds": latency, "device": _device}
