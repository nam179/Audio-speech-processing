"""Download and cache the optional Vietnamese VITS model for offline inference.

Run this once while connected to the Internet. The checkpoint is deliberately
not committed to Git because it is large and has a non-commercial license.
"""
from pathlib import Path

try:
    from transformers import AutoTokenizer, VitsModel
except ModuleNotFoundError as exc:
    raise SystemExit(
        "Missing packages. Install them with: "
        "python -m pip install -r requirements-neural.txt"
    ) from exc

ROOT = Path(__file__).resolve().parent
MODEL_ID = "facebook/mms-tts-vie"
DEST = ROOT / "pretrained_model" / "facebook-mms-tts-vie"
DEST.mkdir(parents=True, exist_ok=True)

print(f"Downloading {MODEL_ID}. This requires an Internet connection.")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
model = VitsModel.from_pretrained(MODEL_ID)
tokenizer.save_pretrained(DEST)
model.save_pretrained(DEST, safe_serialization=True)
print("Saved local model to:", DEST)
print("After downloading, run: python run_neural_tts.py")
