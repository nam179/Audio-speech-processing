# Hướng dẫn đưa Lab 4 lên GitHub

## Upload bằng website

1. Giải nén `Lab4_Project.zip`.
2. Tạo repository mới trên GitHub, ví dụ `CSE457-Lab4-TTS`.
3. Chọn **Add file → Upload files**.
4. Kéo toàn bộ nội dung bên trong thư mục `Lab4_Project` vào vùng upload (không kéo thư mục bọc ngoài). Giữ cả `.gitignore` và `.gitattributes`.
5. Commit với message `Add CSE457 Lab 4 project`.
6. Mở `README.md` trên GitHub và kiểm tra các thư mục `lab4_data`, `audio_output`, `figures` đã được tải lên.

## Upload bằng Git

Mở Terminal tại thư mục gốc `Lab4_Project`:

```bash
git init
git add .
git status
git commit -m "Add CSE457 Lab 4 project"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

Thay `USERNAME/REPOSITORY` bằng tài khoản và tên repository của bạn. Nếu đã tồn tại remote, không chạy lại `git remote add origin`.

## Trước khi nộp

- Điền thông tin sinh viên trong `Bao_cao_Lab4.docx`.
- Chạy `python verify_submission.py`.
- Đọc `SUBMISSION_STATUS.md`; Neural TTS và listening test vẫn cần chạy/đánh giá trên máy có model và người nghe.
- Không upload `.venv/`, `__pycache__/` hoặc `pretrained_model/`.
- Không bỏ `lab4_data/units/`, `lab4_data/hmm_demo/`, `audio_output/` hoặc `figures/`.
