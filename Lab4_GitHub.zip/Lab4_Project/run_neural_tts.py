from pathlib import Path
import json

import librosa
import librosa.display
import matplotlib.pyplot as plt
import pandas as pd

from Lab04 import TEST_SENTENCES, OUTPUT_DIR, FIGURES_DIR
from lab4_data.neural_tts_backend import synthesize

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
rows = []

for i, text in enumerate(TEST_SENTENCES, start=1):
    out_path = OUTPUT_DIR / ("neural_tts.wav" if i == 1 else f"neural_tts_{i}.wav")
    waveform, sr, extra = synthesize(text, out_path, local_files_only=True, seed=1000 + i)
    rows.append({
        "sentence_id": i,
        "text": text,
        "model_id": extra["model_id"],
        "sample_rate": sr,
        "duration_seconds": len(waveform) / sr,
        "latency_seconds": extra["latency_seconds"],
        "device": extra["device"],
        "seed": extra["seed"],
        "real_time_factor": extra["latency_seconds"] / max(len(waveform) / sr, 1e-9),
    })
    if i == 1:
        mel = librosa.feature.melspectrogram(
            y=waveform, sr=sr, n_fft=1024, hop_length=256, n_mels=80
        )
        mel_db = librosa.power_to_db(mel, ref=mel.max())
        plt.figure(figsize=(10, 4))
        librosa.display.specshow(
            mel_db, sr=sr, hop_length=256, x_axis="time", y_axis="mel"
        )
        plt.title("Neural TTS mel-spectrogram")
        plt.colorbar(format="%+2.0f dB")
        plt.tight_layout()
        plt.savefig(FIGURES_DIR / "10_neural_mel_spectrogram.png", dpi=160)
        plt.close()

pd.DataFrame(rows).to_csv(
    OUTPUT_DIR / "neural_tts_latency.csv", index=False, encoding="utf-8-sig"
)
print(pd.DataFrame(rows).to_string(index=False))
print("Saved three Neural TTS files to", OUTPUT_DIR)
