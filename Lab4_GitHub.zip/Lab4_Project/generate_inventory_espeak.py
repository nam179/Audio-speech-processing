"""Optional reproducibility helper to regenerate the bundled synthetic WAV inventory.

Requires the `espeak` or `espeak-ng` command with Vietnamese voice support.
The ready-to-run project already includes the 32 generated WAV files, so this
script is not needed for normal execution.
"""
from pathlib import Path
import shutil
import subprocess

import librosa
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "lab4_data" / "units"
WORDS = {
    "moi": "mời", "khach": "khách", "hang": "hàng", "so": "số",
    "khong": "không", "mot": "một", "hai": "hai", "ba": "ba",
    "bon": "bốn", "nam": "năm", "sau": "sáu", "bay": "bảy",
    "tam": "tám", "chin": "chín", "den": "đến", "quay": "quầy",
}


def main():
    executable = shutil.which("espeak-ng") or shutil.which("espeak")
    if not executable:
        raise SystemExit(
            "Không tìm thấy espeak/espeak-ng. Bộ WAV mẫu đã có sẵn trong "
            "lab4_data/units nên không cần chạy script này."
        )
    OUT.mkdir(parents=True, exist_ok=True)
    for slug, word in WORDS.items():
        for candidate, speed in ((1, 145), (2, 165)):
            path = OUT / f"{slug}_{candidate:02d}.wav"
            temporary = OUT / f"{slug}_{candidate:02d}.raw.wav"
            subprocess.run(
                [executable, "-v", "vi", "-s", str(speed), "-w", str(temporary), word],
                check=True,
            )
            audio, sr = sf.read(str(temporary), dtype="float32")
            if audio.ndim == 2:
                audio = audio.mean(axis=1)
            if sr != 16000:
                audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
            audio = np.asarray(audio, dtype=np.float32)
            # Trim long leading/trailing silence, preserving 20 ms context.
            _, interval = librosa.effects.trim(
                audio, top_db=40, frame_length=512, hop_length=128
            )
            start = max(0, int(interval[0]) - 320)
            end = min(len(audio), int(interval[1]) + 320)
            audio = audio[start:end]
            sf.write(str(path), audio, 16000, subtype="PCM_16")
            temporary.unlink(missing_ok=True)
    print(f"Generated {len(WORDS) * 2} synthetic WAV units in {OUT}")


if __name__ == "__main__":
    main()
