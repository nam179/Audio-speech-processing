from pathlib import Path
import json
import pandas as pd
from docx import Document
from docx.shared import Cm, Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
summary = json.loads((ROOT/'run_summary.json').read_text(encoding='utf-8'))
meta = pd.read_csv(ROOT/'lab4_data'/'metadata.csv')
joins = pd.read_csv(ROOT/'audio_output'/'join_costs.csv')
tests = pd.read_csv(ROOT/'audio_output'/'three_sentence_test.csv')

# Cost comparison for the same configured objective and unweighted join totals.
fixed_objective = summary['fixed_candidate_objective_cost']
dp_objective = summary['dynamic_programming_total_cost']
fixed_join_sum = summary['fixed_candidate_total_join_cost']
dp_join_sum = float(joins['selected_join_cost'].sum())
join_reduction = (fixed_join_sum-dp_join_sum)/fixed_join_sum*100 if fixed_join_sum else 0.0
obj_reduction = (fixed_objective-dp_objective)/fixed_objective*100

D = Document()
sec = D.sections[0]
sec.top_margin = Cm(1.8)
sec.bottom_margin = Cm(1.8)
sec.left_margin = Cm(2.0)
sec.right_margin = Cm(2.0)

styles = D.styles
styles['Normal'].font.name = 'Arial'
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')
styles['Normal'].font.size = Pt(10)
styles['Normal'].paragraph_format.space_after = Pt(5)
for stylename, size, color in [('Title', 24, '17365D'), ('Heading 1', 16, '17365D'), ('Heading 2', 12, '1F4E79'), ('Heading 3', 10.5, '1F4E79')]:
    s = styles[stylename]
    s.font.name = 'Arial'
    s._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')
    s.font.size = Pt(size)
    s.font.bold = True
    s.font.color.rgb = RGBColor.from_string(color)

# Header/footer
header = sec.header.paragraphs[0]
header.text = 'CSE457 | LAB 4 – TỔNG HỢP TIẾNG NÓI'
header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
for r in header.runs:
    r.font.name='Arial'; r.font.size=Pt(8); r.font.color.rgb=RGBColor(100,100,100)
footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = footer.add_run('Báo cáo thực hành | Trang ')
run.font.size = Pt(8)
fld = OxmlElement('w:fldSimple'); fld.set(qn('w:instr'), 'PAGE'); footer._p.append(fld)


def shade(cell, fill='D9EAF7'):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd'); shd.set(qn('w:fill'), fill); tcPr.append(shd)


def set_cell_text(cell, text, bold=False, size=9):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(str(text)); r.bold = bold; r.font.name='Arial'; r.font.size=Pt(size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(headers, rows, widths=None, size=8.5):
    table = D.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    for i,h in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], h, True, size)
        shade(table.rows[0].cells[i])
    for row in rows:
        cells = table.add_row().cells
        for i,val in enumerate(row): set_cell_text(cells[i], val, False, size)
    if widths:
        for row in table.rows:
            for i,w in enumerate(widths): row.cells[i].width = Inches(w)
    D.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def para(text='', boldlead=None, italic=False):
    p = D.add_paragraph()
    if boldlead and text.startswith(boldlead):
        p.add_run(boldlead).bold = True
        p.add_run(text[len(boldlead):])
    else:
        r=p.add_run(text); r.italic=italic
    return p


def bullet(text):
    p=D.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(text); return p


def figure(path, caption, width=6.0):
    p=D.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(ROOT/path), width=Inches(width))
    cp=D.add_paragraph(); cp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    rr=cp.add_run(caption); rr.italic=True; rr.font.size=Pt(8.5)

# PAGE 1
p=D.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('TRƯỜNG ĐẠI HỌC THỦY LỢI'); r.bold=True; r.font.size=Pt(14)
p=D.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('KHOA CÔNG NGHỆ THÔNG TIN'); r.bold=True; r.font.size=Pt(12)
for _ in range(2): D.add_paragraph()
p=D.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('BÁO CÁO THỰC HÀNH LAB 4'); r.bold=True; r.font.size=Pt(22); r.font.color.rgb=RGBColor(23,54,93)
p=D.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('TỔNG HỢP TIẾNG NÓI – TEXT TO SPEECH'); r.bold=True; r.font.size=Pt(16)
D.add_paragraph()
add_table(['Thông tin','Nội dung'], [
    ['Học phần','CSE457 – Xử lý âm thanh và tiếng nói'],
    ['Sinh viên','........................................................'],
    ['Mã sinh viên','........................................................'],
    ['Lớp','65TTNT'],
    ['Giảng viên','........................................................'],
    ['Ngày thực hiện','02/11/2026']
], [2.0,4.3], 10)
D.add_paragraph()
p=D.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Phạm vi báo cáo'); r.bold=True; r.font.size=Pt(12)
p=D.add_paragraph('Báo cáo triển khai pipeline ghép nối word-unit, chọn candidate bằng dynamic programming, cross-fade, phân tích F0 và minh họa trajectory tham số kiểu HMM. Inventory được tạo bằng giọng eSpeak tiếng Việt để kiểm thử chương trình. Đây là dữ liệu tổng hợp, không phải bản ghi giọng nói người thật.')
p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
D.add_page_break()

# PAGE 2
D.add_heading('1. Mục tiêu và môi trường thực nghiệm', level=1)
para('Mục tiêu của Lab 4 là xây dựng một mini Text-to-Speech (TTS), xử lý văn bản đầu vào, ánh xạ token sang word-unit, ghép các waveform, giảm discontinuity tại biên và khảo sát các hướng tổng hợp tham số/HMM cũng như neural TTS.')
D.add_heading('1.1. Cấu hình', level=2)
add_table(['Thành phần','Thiết lập'], [
    ['Tần số lấy mẫu','16.000 Hz'],
    ['Kênh','Mono'],
    ['Định dạng file','WAV PCM 16-bit'],
    ['Inventory','16 từ/đơn vị, 2 candidate mỗi đơn vị'],
    ['Tổng số unit','32 WAV'],
    ['Thư viện','NumPy, SciPy, pandas, SoundFile, librosa, Matplotlib'],
    ['Nguồn giọng mẫu','eSpeak Vietnamese – giọng tổng hợp'],
], [2.0,4.3], 9)
D.add_heading('1.2. Text normalization', level=2)
para('Câu chính: “Mời khách hàng số 23 đến quầy 5.” Quy ước của case study là đọc chuỗi số theo từng chữ số, vì vậy 23 được chuyển thành “hai ba”, còn 5 được chuyển thành “năm”.')
para('Chuỗi token sau chuẩn hóa: mời – khách – hàng – số – hai – ba – đến – quầy – năm.')
para('Hàm normalize_queue_text() chuyển văn bản thành chữ thường, loại dấu câu, tách token và thay từng chữ số bằng từ tiếng Việt tương ứng. Quy tắc này phù hợp với miền hẹp thông báo xếp hàng trong đề bài.')
D.add_heading('1.3. Inventory và metadata', level=2)
para(f'Chương trình đã đọc {len(meta)} file WAV thuộc {meta["label"].nunique()} nhãn. Metadata lưu label, speaker, duration, RMS, sample rate, số kênh và đường dẫn file. Hai histogram dưới đây giúp quan sát phân bố duration và RMS của inventory mẫu.')
figure('figures/01_inventory_combined.png', 'Hình 1. Phân bố duration (trái) và RMS (phải) của inventory.', 6.1)
D.add_page_break()

# PAGE 3
D.add_heading('2. Baseline concatenation', level=1)
D.add_heading('2.1. Phương pháp', level=2)
para('Baseline chọn candidate số 1 của mỗi token, đọc waveform, chuyển về mono nếu cần, chuẩn hóa mức RMS khi ghép và nối trực tiếp các mảng mẫu bằng NumPy concatenate. Kết quả được lưu tại audio_output/raw_concat.wav.')
para('Ghép trực tiếp không xử lý vùng chuyển tiếp. Nếu hai unit có khác biệt về biên độ, pha hoặc phổ ở điểm nối, tín hiệu có thể xuất hiện click hoặc thay đổi âm sắc đột ngột. Do đó cần kiểm tra cả waveform và spectrogram quanh biên nối.')
D.add_heading('2.2. Kết quả quan sát', level=2)
figure('figures/03_spectrogram_before_after.png', 'Hình 2. So sánh spectrogram của ghép trực tiếp và ghép cross-fade 15 ms.', 6.1)
para('Các hình được tạo trực tiếp từ audio_output/raw_concat.wav và audio_output/best_concat.wav. Cross-fade thay đổi vùng tín hiệu quanh điểm nối, vì vậy cần đánh giá đồng thời độ liên tục và mức rõ của phụ âm. Việc hình ảnh mượt hơn không tự động chứng minh câu nghe tự nhiên hơn; cần có listening test để kết luận.')
D.add_page_break()

# PAGE 4
D.add_heading('3. Unit selection và boundary smoothing', level=1)
D.add_heading('3.1. Target cost và join cost', level=2)
para('Target cost đánh giá mức phù hợp của một candidate với mục tiêu duration/RMS của token. Join cost đánh giá khác biệt phổ giữa phần cuối unit trái và phần đầu unit phải. Trong chương trình, join cost dùng mean-square difference giữa log-magnitude spectrum của hai vùng biên 25 ms.')
para('Dynamic programming lưu chi phí nhỏ nhất tại từng vị trí token và candidate. Trọng số join cost được đặt λ = 0,0005 để kết hợp với target cost. Các tham số này là thiết lập thực nghiệm của chương trình, không phải hằng số bắt buộc của phương pháp.')
D.add_heading('3.2. Kết quả chọn candidate', level=2)
selected_description = ' – '.join(f"{token}: candidate {candidate}" for token, candidate in zip(summary['tokens'], summary['selected_candidate_indices_1_based']))
para('Dynamic programming chọn chuỗi: %s. Trên inventory mẫu này, tổng join cost của chuỗi DP là %.2f, trong khi chuỗi cố định candidate 1 là %.2f, giảm %.2f%%. Tổng objective cost tương ứng giảm từ %.4f xuống %.4f (%.2f%%).' % (selected_description, dp_join_sum, fixed_join_sum, join_reduction, fixed_objective, dp_objective, obj_reduction))
para('Kết quả trên chỉ phản ánh các waveform eSpeak đã tạo và hàm cost được định nghĩa trong code. Nó không chứng minh mức naturalness tăng tương ứng, vì naturalness cần đánh giá chủ quan bằng người nghe.')
figure('figures/05_unit_selection_costs.png', 'Hình 5. So sánh objective cost và join cost tại các biên được chọn.', 6.1)
rows=[]
for _,r in joins.head(8).iterrows():
    rows.append([f'{r.left_token} → {r.right_token}', int(r.left_candidate), int(r.right_candidate), f'{r.selected_join_cost:.2f}'])
add_table(['Biên nối','Candidate trái','Candidate phải','Join cost'], rows, [2.2,1.2,1.2,1.2], 8)
D.add_heading('3.3. Cross-fade', level=2)
para('Cross-fade trộn N mẫu cuối của unit trước với N mẫu đầu của unit sau theo ramp α từ 0 đến 1. Chương trình tạo bốn bản thử: 0, 5, 15 và 30 ms. Bản 15 ms được lưu thêm tại best_concat.wav để làm kết quả đề xuất của lần chạy này; không khẳng định 15 ms là tối ưu cho mọi giọng hoặc mọi cặp unit.')
D.add_page_break()

# PAGE 5
D.add_heading('4. Prosody và source–filter', level=1)
D.add_heading('4.1. F0', level=2)
para('F0 được ước lượng trên unit “mời” bằng thuật toán YIN trong librosa. Với một đoạn hữu thanh gần tuần hoàn, nếu chu kỳ là Np mẫu thì F0 xấp xỉ Fs/Np. Ví dụ Fs = 16 kHz và Np = 100 mẫu cho F0 xấp xỉ 160 Hz.')
figure('figures/06_f0_contour.png', 'Hình 3. F0 contour ước lượng từ unit mời_01 bằng YIN.', 6.1)
D.add_heading('4.2. Thay đổi duration và pitch', level=2)
para('Chương trình tạo bản time-stretch ở tốc độ 0,8×, 1,0× và 1,2×; đồng thời tạo bản pitch shift −2 và +2 semitone. Công thức tỷ số tần số là r = 2^(Δs/12). Các file nằm trong audio_output/. Khi nghe, cần chú ý hiện tượng biến dạng âm, “chipmunk”, buzziness và sự thay đổi độ rõ.')
D.add_heading('4.3. Source–filter', level=2)
para('Mô hình source–filter mô tả X(z) = E(z)H(z), trong đó E(z) là nguồn kích thích và H(z) là bộ lọc đường thanh quản. Âm hữu thanh có nguồn kích thích gần tuần hoàn; âm vô thanh có nguồn gần nhiễu. F0 gắn với chu kỳ nguồn kích thích, trong khi formant gắn với đặc tính bộ lọc. Do đó thay F0 không đồng nghĩa với dịch formant.')
D.add_heading('5. HMM-based parametric synthesis', level=1)
para('Đã tạo backend HMM minh họa gồm 16 mô hình word-HMM, mỗi mô hình có 5 state Gaussian emission theo topology left-to-right. Mỗi WAV mẫu được chia thành năm vùng liên tiếp để căn chỉnh có giám sát; từ các frame của hai candidate, chương trình ước lượng trung bình/phương sai của log-mel spectrum, F0, năng lượng và thời lượng state. Ma trận chuyển trạng thái cho phép ở lại state hiện tại hoặc chuyển sang state kế tiếp.')
para('Khi tổng hợp, chuỗi token đã chuẩn hóa xác định thứ tự các word-HMM. Backend phát sinh state-mean trajectory và duration theo từng state, ghép thành log-mel spectrogram rồi dùng mel inversion + Griffin-Lim để tạo waveform. Kết quả được lưu tại audio_output/hmm_tts.wav (16 kHz).')
para('Đây là HMM TTS demo quy mô nhỏ được huấn luyện từ inventory eSpeak tổng hợp với căn chỉnh thời gian đơn giản; không phải hệ HMM production và không dùng Baum–Welch/MLPG đầy đủ. Các tham số và trajectory có thể kiểm tra trong lab4_data/hmm_demo/.')
figure('figures/07_hmm_f0_trajectory.png', 'Hình 7. F0 trajectory được phát sinh từ các state của HMM.', 6.1)
figure('figures/08_hmm_spectral_trajectory.png', 'Hình 8. Trajectory phổ trung bình theo frame từ HMM.', 6.1)
D.add_page_break()

# PAGE 6
D.add_heading('6. Test nhiều câu và đánh giá', level=1)
para('Ba câu test được dùng để kiểm tra pipeline ghép nối và tạo file tham chiếu eSpeak cổ điển. Thời gian của eSpeak tham chiếu chỉ là phép đo chạy trên môi trường tạo bộ dữ liệu này; đây không phải phép đo neural TTS và không thể so trực tiếp với thời gian trên máy sinh viên.')
rows=[]
for _,r in tests.iterrows():
    rows.append([int(r.sentence_id), r.text, int(r.token_count), f'{r.concat_duration_seconds:.3f}', f'{r.espeak_reference_latency_seconds:.4f}'])
add_table(['ID','Câu test','Số token','Audio concat (s)','eSpeak time (s)'], rows, [0.45,2.5,0.7,1.1,1.1], 7.5)
D.add_heading('6.1. Listening test', level=2)
para('File audio_output/ratings_template.csv được tạo để người nghe điền điểm. Chưa có người nghe thực tế cung cấp đánh giá, vì vậy báo cáo không tự đặt MOS hoặc intelligibility. Sau khi thu thập dữ liệu, MOS được tính bằng trung bình điểm naturalness 1–5; intelligibility có thể tính theo tỷ lệ từ/câu nhận diện đúng.')
D.add_heading('6.2. So sánh ba hướng tổng hợp', level=2)
add_table(['Phương pháp','Trạng thái trong gói bài','Nhận xét hợp lệ'], [
    ['Concatenation','Đã chạy','Có raw_concat.wav, best_concat.wav và các biến thể cross-fade.'],
    ['HMM/parametric','Đã chạy HMM demo 5-state','Có state sequence, F0/spectral/duration trajectory và hmm_tts.wav; vocoder dùng Griffin-Lim.'],
    ['Neural TTS','Đã tạo wrapper VITS; chưa inference','Cần cài requirements-neural.txt và tải model checkpoint; chưa có neural_tts.wav trong lần chạy này.']
], [1.3,1.5,3.6], 8)
D.add_heading('6.3. Hạn chế và phần cần bổ sung', level=2)
bullet('Thay inventory eSpeak bằng bản ghi người thật, cùng microphone, khoảng cách và 16 kHz mono; mỗi unit nên có ít nhất hai lần thu.')
bullet('HMM hiện là demo Gaussian left-to-right 5 state/word trên inventory tổng hợp, dùng căn chỉnh chia đều theo thời gian; nếu giảng viên yêu cầu HMM huấn luyện Baum–Welch hoặc MLPG, cần bổ sung theo cấu hình lớp.')
bullet('Đã chuẩn bị wrapper cho facebook/mms-tts-vie (VITS). Cần cài Transformers và tải model trước buổi Lab; sau đó chạy prepare_neural_model.py một lần rồi run_neural_tts.py offline. Model card ghi giấy phép CC BY-NC 4.0.')
bullet('Cần người nghe chấm tối thiểu ba câu để báo cáo MOS/intelligibility; không điền điểm giả định.')
D.add_page_break()

# PAGE 7
D.add_heading('7. Kết luận', level=1)
para('Bài thực hành đã triển khai được các bước có thể tái lập với inventory mẫu: text normalization, thống kê metadata, baseline concatenation, tính join cost, chọn chuỗi candidate bằng dynamic programming, cross-fade 0/5/15/30 ms, phân tích F0, time-stretch/pitch shift và backend HMM 5-state có sinh trajectory tham số và waveform demo.')
para('Trong lần chạy này, objective cost giảm từ %.4f xuống %.4f; tổng join cost giảm %.2f%% so với chuỗi cố định candidate 1. Kết quả cho thấy tiêu chí cost của chương trình ưu tiên được chuỗi candidate có biên phổ gần nhau hơn trong inventory mẫu. Cần listening test mới có thể kết luận về naturalness và intelligibility.' % (fixed_objective, dp_objective, join_reduction))
para('Neural TTS inference chưa chạy trong môi trường tạo gói vì không có kết nối mạng để tải checkpoint và chưa cài Transformers. Gói có wrapper cho facebook/mms-tts-vie (VITS), script tải model và script inference ba câu; cần chạy các bước này trên máy có Internet để tạo neural_tts.wav, neural_tts_2.wav, neural_tts_3.wav và latency. HMM đã sinh waveform bằng mel inversion/Griffin-Lim nhưng vẫn là mô hình demo nhỏ, không phải hệ production.')
D.add_heading('8. Trả lời câu hỏi báo cáo', level=1)
answers = [
('Câu 1. Vì sao ghép các đoạn tự nhiên vẫn kém tự nhiên?', 'Các unit được thu riêng có thể khác duration, F0, energy, spectral envelope và ngữ cảnh đồng phát âm. Ghép tại biên không phù hợp làm câu bị click, ngắt nhịp hoặc đổi âm sắc đột ngột.'),
('Câu 2. Target cost và join cost khác nhau thế nào?', 'Target cost đo mức phù hợp của candidate với unit cần phát; join cost đo độ tương thích giữa hai candidate kề nhau. Chỉ tối ưu join cost có thể chọn các unit nối êm nhưng sai nội dung, ngữ điệu hoặc duration.'),
('Câu 3. Vì sao cross-fade quá dài làm mờ phụ âm?', 'Vùng trộn dài khiến hai đoạn âm chồng lấn trong thời gian lâu. Các chuyển tiếp phổ nhanh của phụ âm có thể bị trộn với unit kế tiếp, làm giảm độ rõ.'),
('Câu 4. Vì sao đổi F0 không đồng nghĩa đổi formant?', 'Trong X(z)=E(z)H(z), F0 chủ yếu gắn với chu kỳ nguồn kích thích E(z); formant gắn với đáp ứng bộ lọc đường thanh quản H(z). Hai đại lượng có vai trò khác nhau.'),
('Câu 5. PSOLA đổi pitch thế nào và vì sao có thể buzziness?', 'TD-PSOLA lấy các đoạn quanh pitch epoch, nhân cửa sổ rồi dịch và overlap-add với khoảng cách epoch mới. Kéo dài/lặp quá mức có thể tạo tính tuần hoàn nhân tạo, gây cảm giác buzziness.'),
('Câu 6. Vì sao delta feature làm trajectory HMM trơn hơn?', 'Delta biểu diễn biến thiên đặc trưng giữa các frame. Tối ưu cả đặc trưng tĩnh và delta ràng buộc mức thay đổi theo thời gian, giảm bước nhảy giữa frame.'),
('Câu 7. Vì sao whole-waveform concatenation cần inventory lớn?', 'Nhiều candidate cung cấp thêm lựa chọn theo ngữ cảnh, duration, F0 và phổ. Hệ thống có cơ hội chọn unit khớp mục tiêu và biên nối hơn.'),
('Câu 8. Nêu hai khác biệt giữa concatenative và neural TTS.', 'Concatenative phát lại rồi ghép waveform thu sẵn và phụ thuộc inventory. Neural TTS học ánh xạ văn bản–đặc trưng âm học từ dữ liệu và sinh waveform qua acoustic model/vocoder; hai hệ có nguồn lỗi và yêu cầu tài nguyên khác nhau.'),
('Câu 9. Vì sao không dùng model neural tùy ý tải trong giờ Lab?', 'Model khác phiên bản, dữ liệu, cấu hình và thiết bị có thể cho chất lượng/latency khác nhau, làm phép so sánh thiếu công bằng và khó tái lập. Model cần được thống nhất và chuẩn bị offline trước buổi Lab.'),
('Câu 10. MOS cao nhưng intelligibility thấp phù hợp ứng dụng nào?', 'Có thể cân nhắc tác vụ âm thanh nền hoặc nội dung giải trí không đòi hỏi truyền đạt chính xác. Không phù hợp thông báo xếp hàng hay hướng dẫn quan trọng vì người nghe có thể không hiểu đúng nội dung.')
]
for q,a in answers:
    p=D.add_paragraph(); p.paragraph_format.space_after=Pt(2); p.paragraph_format.line_spacing=1.0; p.paragraph_format.keep_together=True
    r=p.add_run(q+' '); r.bold=True; r.font.size=Pt(8)
    r=p.add_run(a); r.font.size=Pt(8)

D.add_heading('Tài liệu tham khảo', level=2)
para('Tài liệu thực hành CSE457 – Xử lý âm thanh và tiếng nói, Lab 4: Tổng hợp tiếng nói, Trường Đại học Thủy Lợi, các mục 3–10.')
para('X. Huang, A. Acero, H.-W. Hon, Spoken Language Processing, 2001; L. R. Rabiner, R. W. Schafer, Theory and Applications of Digital Speech Processing, 2010.')
para('Meta, facebook/mms-tts-vie (VITS), https://huggingface.co/facebook/mms-tts-vie; giấy phép CC BY-NC 4.0.')

out = ROOT / 'Bao_cao_Lab4.docx'
D.save(out)
print(out)
