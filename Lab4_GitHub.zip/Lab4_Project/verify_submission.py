from __future__ import annotations

from collections import Counter
from pathlib import Path
import sys

import pandas as pd
import soundfile as sf

ROOT = Path(__file__).resolve().parent
REQUIRED_FILES = [
    "Lab04.py",
    "Bao_cao_Lab4.docx",
    "README.md",
    "requirements.txt",
    "lab4_data/metadata.csv",
    "lab4_data/neural_tts_backend.py",
    "lab4_data/hmm_demo/train_hmm.py",
    "lab4_data/hmm_demo/backend.py",
    "lab4_data/hmm_demo/gaussian_hmm_model.npz",
    "lab4_data/hmm_demo/transition_matrix.json",
    "lab4_data/hmm_demo/generated_trajectory.csv",
    "audio_output/raw_concat.wav",
    "audio_output/best_concat.wav",
    "audio_output/hmm_tts.wav",
    "audio_output/join_costs.csv",
    "audio_output/three_sentence_test.csv",
    "audio_output/ratings_template.csv",
    "figures/01_inventory_combined.png",
    "figures/03_spectrogram_before_after.png",
    "figures/04_boundary_waveforms.png",
    "figures/05_unit_selection_costs.png",
    "figures/06_f0_contour.png",
    "figures/07_hmm_f0_trajectory.png",
    "figures/08_hmm_spectral_trajectory.png",
    "figures/09_hmm_generated_mel.png",
]

missing = [name for name in REQUIRED_FILES if not (ROOT / name).is_file()]
errors: list[str] = []
unit_paths = sorted((ROOT / "lab4_data" / "units").glob("*.wav"))
counts = Counter(path.stem.rsplit("_", 1)[0] for path in unit_paths)
if len(unit_paths) != 32:
    errors.append(f"Expected 32 inventory WAV files; found {len(unit_paths)}")
if len(counts) != 16:
    errors.append(f"Expected 16 inventory labels; found {len(counts)}")
for label, count in counts.items():
    if count != 2:
        errors.append(f"Inventory label {label}: expected 2 candidates, found {count}")

for path in unit_paths:
    try:
        info = sf.info(str(path))
        if info.samplerate != 16000 or info.channels != 1:
            errors.append(
                f"{path.name}: expected mono 16000 Hz, got {info.channels} ch / {info.samplerate} Hz"
            )
    except Exception as exc:
        errors.append(f"{path.name}: cannot read WAV ({exc})")

for relative in [
    "audio_output/raw_concat.wav",
    "audio_output/best_concat.wav",
    "audio_output/hmm_tts.wav",
]:
    path = ROOT / relative
    if path.exists():
        try:
            info = sf.info(str(path))
            if info.samplerate != 16000 or info.channels != 1:
                errors.append(
                    f"{relative}: expected mono 16000 Hz, got {info.channels} ch / {info.samplerate} Hz"
                )
        except Exception as exc:
            errors.append(f"{relative}: cannot read WAV ({exc})")

metadata_path = ROOT / "lab4_data" / "metadata.csv"
if metadata_path.exists():
    metadata = pd.read_csv(metadata_path)
    expected_columns = {"label", "speaker", "duration", "RMS", "sample_rate", "channels", "file_path"}
    if not expected_columns.issubset(metadata.columns):
        errors.append("metadata.csv is missing one or more required columns")
    if len(metadata) != 32:
        errors.append(f"metadata.csv should have 32 rows; found {len(metadata)}")

print("=== CSE457 Lab 4 repository verification ===")
print(f"Required project files: {len(REQUIRED_FILES) - len(missing)}/{len(REQUIRED_FILES)} present")
print(f"Inventory files: {len(unit_paths)} WAV / {len(counts)} labels")
print("HMM backend: five-state Gaussian left-to-right demo; hmm_tts.wav checked")
print(
    "Neural TTS: "
    + ("inference output present" if (ROOT / "audio_output" / "neural_tts.wav").is_file()
       else "wrapper present; model inference not yet run (optional checkpoint download required)")
)
print(
    "Listening test: "
    + ("ratings file has entries" if len(pd.read_csv(ROOT / "audio_output" / "ratings_template.csv")) > 0
       else "template only; real listener ratings still required")
)
if missing:
    print("Missing required files:")
    for item in missing:
        print(" -", item)
if errors:
    print("Validation errors:")
    for item in errors:
        print(" -", item)
if missing or errors:
    sys.exit(1)
print("Core repository and generated outputs passed verification.")
