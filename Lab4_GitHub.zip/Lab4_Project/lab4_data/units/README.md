# Inventory WAV

This folder contains a compact Vietnamese word-unit inventory for the Lab 4 queue-announcement case study.

- 16 labels: `mời`, `khách`, `hàng`, `số`, `không`, `một`, `hai`, `ba`, `bốn`, `năm`, `sáu`, `bảy`, `tám`, `chín`, `đến`, `quầy`.
- Two candidate recordings for each label (`*_01.wav`, `*_02.wav`): 32 WAV files total.
- Format: 16 kHz, mono, PCM 16-bit.
- Provenance: eSpeak Vietnamese synthetic speech, not human recordings.
- `../metadata.csv` stores label, synthetic speaker tag, duration, RMS, sample rate, channel count and file path.

The generated voice samples are intended for code testing and demonstration of text normalization, concatenation, candidate selection and acoustic analysis. They are not a substitute for human recordings in a perceptual naturalness study.
