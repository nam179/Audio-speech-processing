# Optional Neural TTS backend

The project includes `neural_tts_backend.py` for the official Vietnamese VITS checkpoint `facebook/mms-tts-vie`.

Model information and example inference are documented on the Hugging Face model card:
https://huggingface.co/facebook/mms-tts-vie

The model card identifies this as a Vietnamese VITS TTS checkpoint and lists the license as **CC-BY-NC 4.0**. It is therefore suitable only for non-commercial use under that license; review the model card and license before any other use.

The pretrained weights are intentionally not committed to this repository: the repository is large, and GitHub has a 100 MB per-file limit for ordinary Git files. Download the weights locally before offline inference:

```powershell
py -m pip install -r requirements-neural.txt
py prepare_neural_model.py
py run_neural_tts.py
```

When inference completes, the script writes:

- `audio_output/neural_tts.wav`
- `audio_output/neural_tts_2.wav`
- `audio_output/neural_tts_3.wav`
- `audio_output/neural_tts_latency.csv`
- `figures/10_neural_mel_spectrogram.png`

A model download/inference has not been represented as complete unless those output files exist. The core concatenative and HMM-demo pipelines do not require this optional model.
