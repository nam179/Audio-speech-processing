from __future__ import annotations

from pathlib import Path
import time

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]
MODEL_ID = "facebook/mms-tts-vie"
MODEL_DIR = ROOT / "pretrained_model" / "facebook-mms-tts-vie"

_tokenizer = None
_model = None
_torch = None
_device = None


def load_model(local_files_only: bool = True):
    global _tokenizer, _model, _torch, _device
    if _tokenizer is not None and _model is not None:
        return _tokenizer, _model

    try:
        import torch
        from transformers import AutoTokenizer, VitsModel
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Thiếu thư viện Neural TTS. Hãy chạy: "
            "python -m pip install -r requirements-neural.txt"
        ) from exc

    source = str(MODEL_DIR) if (MODEL_DIR / "config.json").exists() else MODEL_ID
    if local_files_only and source == MODEL_ID:
        raise FileNotFoundError(
            "Chưa có pretrained model cục bộ. Khi có Internet, chạy "
            "python prepare_neural_model.py để tải facebook/mms-tts-vie. "
            "Sau đó có thể chạy Neural TTS offline."
        )

    _device = "cuda" if torch.cuda.is_available() else "cpu"
    _tokenizer = AutoTokenizer.from_pretrained(
        source, local_files_only=local_files_only
    )
    _model = VitsModel.from_pretrained(
        source, local_files_only=local_files_only
    ).to(_device)
    _model.eval()
    _torch = torch
    return _tokenizer, _model


def synthesize(text: str, output_path=None, local_files_only: bool = True,
               seed: int = 1234):
    tokenizer, model = load_model(local_files_only=local_files_only)
    _torch.manual_seed(seed)
    inputs = tokenizer(text, return_tensors="pt")
    inputs = {key: value.to(_device) for key, value in inputs.items()}

    start = time.perf_counter()
    with _torch.no_grad():
        waveform = model(**inputs).waveform[0].detach().cpu().numpy()
    latency = time.perf_counter() - start

    sample_rate = int(model.config.sampling_rate)
    waveform = np.asarray(waveform, dtype=np.float32)
    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(output_path), waveform, sample_rate, subtype="PCM_16")

    return waveform, sample_rate, {
        "latency_seconds": latency,
        "device": _device,
        "model_id": MODEL_ID,
        "seed": seed,
    }
