"""Educational left-to-right Gaussian HMM TTS demonstration."""
