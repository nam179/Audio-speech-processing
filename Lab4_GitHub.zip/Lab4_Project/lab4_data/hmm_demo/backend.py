from __future__ import annotations

import re
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

from .train_hmm import LABELS, HOP, N_FFT, N_MELS, SR, train

ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = Path(__file__).resolve().parent / "gaussian_hmm_model.npz"
DIGITS = {
    "0": "không", "1": "một", "2": "hai", "3": "ba", "4": "bốn",
    "5": "năm", "6": "sáu", "7": "bảy", "8": "tám", "9": "chín",
}


def normalize_queue_text(text: str) -> list[str]:
    clean = re.sub(r"[^\w\sÀ-ỹ]", " ", text.lower(), flags=re.UNICODE)
    tokens = []
    for token in clean.split():
        if token.isdigit():
            tokens.extend(DIGITS[digit] for digit in token)
        else:
            tokens.append(token)
    return tokens


def load_model():
    if not MODEL_PATH.exists():
        train()
    with np.load(MODEL_PATH, allow_pickle=False) as data:
        return {key: data[key] for key in data.files}


def _make_parameter_trajectory(tokens: list[str], model: dict,
                               duration_scale: float, f0_scale: float):
    token_index = {str(name): i for i, name in enumerate(model["token_names"])}
    mel_parts = []
    f0_parts = []
    energy_parts = []
    state_parts = []
    word_parts = []
    frame = 0
    frame_rows = []

    for token_position, token in enumerate(tokens):
        if token not in token_index:
            raise ValueError(f"HMM inventory does not contain token: {token}")
        idx = token_index[token]
        state_durations = np.maximum(
            2, np.rint(model["duration_frames"][idx] * duration_scale).astype(int)
        )
        for state, count in enumerate(state_durations):
            mel_vector = model["mel_means"][idx, state]
            f0_value = float(model["f0_means"][idx, state]) * f0_scale
            energy_value = float(model["energy_means"][idx, state])
            mel_block = np.repeat(mel_vector[:, None], int(count), axis=1)
            mel_parts.append(mel_block)
            f0_parts.extend([f0_value] * int(count))
            energy_parts.extend([energy_value] * int(count))
            state_parts.extend([state] * int(count))
            word_parts.extend([token] * int(count))
            frame_rows.append({
                "token": token,
                "state": state,
                "duration_frames": int(count),
                "duration_seconds": int(count) * HOP / SR,
                "mean_f0_hz": f0_value,
                "mean_energy": energy_value,
            })
            frame += int(count)
        # A short low-energy inter-word gap preserves word boundaries.
        if token_position < len(tokens) - 1:
            gap_frames = 3
            mel_parts.append(np.full((N_MELS, gap_frames), -80.0, dtype=np.float32))
            f0_parts.extend([0.0] * gap_frames)
            energy_parts.extend([0.0] * gap_frames)
            state_parts.extend([-1] * gap_frames)
            word_parts.extend(["silence"] * gap_frames)

    mel_db = np.concatenate(mel_parts, axis=1).astype(np.float32)
    f0_track = np.asarray(f0_parts, dtype=np.float32)
    energy_track = np.asarray(energy_parts, dtype=np.float32)
    state_track = np.asarray(state_parts, dtype=np.int16)
    return mel_db, f0_track, energy_track, state_track, word_parts, frame_rows


def _griffin_lim_from_mel(mel_db: np.ndarray) -> np.ndarray:
    mel_power = np.power(10.0, mel_db / 10.0).astype(np.float32)
    stft_magnitude = librosa.feature.inverse.mel_to_stft(
        mel_power,
        sr=SR,
        n_fft=N_FFT,
        power=2.0,
        fmin=0,
        fmax=SR / 2,
    )
    audio = librosa.griffinlim(
        stft_magnitude,
        n_iter=48,
        hop_length=HOP,
        win_length=N_FFT,
        random_state=0,
    )
    audio = np.asarray(audio, dtype=np.float32)
    peak = float(np.max(np.abs(audio))) if len(audio) else 0.0
    if peak > 1e-8:
        audio = audio * (0.85 / peak)
    return np.clip(audio, -0.98, 0.98)


def synthesize_hmm(text: str, output_path=None, duration_scale: float = 1.0,
                   f0_scale: float = 1.0):
    """Generate a waveform from learned Gaussian HMM state-mean trajectories.

    The output is a pedagogical parametric synthesis demonstration. Acoustic
    parameters are emitted from per-word left-to-right Gaussian HMMs and then
    converted to a waveform by mel inversion with Griffin-Lim.
    """
    if duration_scale <= 0 or f0_scale <= 0:
        raise ValueError("duration_scale and f0_scale must be positive")
    tokens = normalize_queue_text(text)
    model = load_model()
    mel_db, f0_track, energy_track, state_track, words, rows = _make_parameter_trajectory(
        tokens, model, duration_scale, f0_scale
    )
    audio = _griffin_lim_from_mel(mel_db)
    if abs(f0_scale - 1.0) > 1e-6:
        semitones = 12.0 * np.log2(f0_scale)
        audio = librosa.effects.pitch_shift(audio, sr=SR, n_steps=float(semitones))
    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(output_path), audio, SR, subtype="PCM_16")
    tracks = {
        "tokens": tokens,
        "state_sequence": state_track,
        "state_durations": rows,
        "f0": f0_track,
        "energy": energy_track,
        "spectral": np.mean(mel_db, axis=0),
        "mel_spectrogram_db": mel_db,
        "word_sequence": words,
        "frame_rate_hz": SR / HOP,
        "model_type": "5-state left-to-right Gaussian HMM per word; Griffin-Lim waveform reconstruction",
    }
    return audio, SR, tracks


def save_tracks(tracks: dict, output_dir=None):
    out = Path(output_dir) if output_dir else Path(__file__).resolve().parent
    out.mkdir(parents=True, exist_ok=True)
    import pandas as pd
    trajectory = pd.DataFrame({
        "frame": np.arange(len(tracks["f0"])),
        "word": tracks["word_sequence"],
        "state": tracks["state_sequence"],
        "f0_hz": tracks["f0"],
        "energy": tracks["energy"],
        "mean_log_mel_db": tracks["spectral"],
    })
    trajectory.to_csv(out / "generated_trajectory.csv", index=False, encoding="utf-8-sig")
    trajectory.to_csv(out / "hmm_state_tracks.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(tracks["state_durations"]).to_csv(
        out / "generated_state_durations.csv", index=False, encoding="utf-8-sig"
    )
