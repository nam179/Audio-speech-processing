from __future__ import annotations

import json
from pathlib import Path

import librosa
import numpy as np
import pandas as pd
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
UNITS_DIR = ROOT / "lab4_data" / "units"
OUT_DIR = Path(__file__).resolve().parent
SR = 16000
N_MELS = 80
N_STATES = 5
N_FFT = 1024
HOP = 160

LABELS = {
    "moi": "mời", "khach": "khách", "hang": "hàng", "so": "số",
    "khong": "không", "mot": "một", "hai": "hai", "ba": "ba",
    "bon": "bốn", "nam": "năm", "sau": "sáu", "bay": "bảy",
    "tam": "tám", "chin": "chín", "den": "đến", "quay": "quầy",
}


def load_mono(path: Path) -> np.ndarray:
    y, sr = sf.read(str(path), dtype="float32")
    if y.ndim == 2:
        y = y.mean(axis=1)
    if sr != SR:
        y = librosa.resample(y, orig_sr=sr, target_sr=SR)
    return np.asarray(y, dtype=np.float32)


def frame_features(y: np.ndarray):
    mel = librosa.feature.melspectrogram(
        y=y, sr=SR, n_fft=N_FFT, hop_length=HOP,
        n_mels=N_MELS, fmin=0, fmax=SR / 2, power=2.0
    )
    mel_db = librosa.power_to_db(mel, ref=1.0)
    energy = librosa.feature.rms(y=y, frame_length=N_FFT, hop_length=HOP)[0]
    f0 = librosa.yin(
        y, fmin=65, fmax=450, sr=SR,
        frame_length=N_FFT, hop_length=HOP
    )
    n = min(mel_db.shape[1], len(energy), len(f0))
    mel_db = mel_db[:, :n]
    energy = energy[:n]
    f0 = f0[:n]
    voiced = (energy > max(float(energy.max()) * 0.10, 1e-4)) & (f0 >= 65) & (f0 <= 300)
    f0 = np.where(voiced, f0, 0.0)
    return mel_db, energy, f0


def train() -> dict:
    token_names = list(LABELS.values())
    n_tokens = len(token_names)
    mel_means = np.zeros((n_tokens, N_STATES, N_MELS), dtype=np.float32)
    mel_vars = np.zeros_like(mel_means)
    f0_means = np.zeros((n_tokens, N_STATES), dtype=np.float32)
    f0_vars = np.zeros_like(f0_means)
    energy_means = np.zeros((n_tokens, N_STATES), dtype=np.float32)
    duration_frames = np.zeros((n_tokens, N_STATES), dtype=np.float32)
    counts = np.zeros((n_tokens, N_STATES), dtype=np.int32)
    inventory_rows = []

    for token_idx, (slug, label) in enumerate(LABELS.items()):
        paths = sorted(UNITS_DIR.glob(f"{slug}_*.wav"))
        if len(paths) < 2:
            raise FileNotFoundError(
                f"Cần ít nhất hai candidate cho '{label}', tìm thấy {len(paths)} ở {UNITS_DIR}"
            )
        mel_state_samples = [[[] for _ in range(N_MELS)] for _ in range(N_STATES)]
        f0_state_samples = [[] for _ in range(N_STATES)]
        energy_state_samples = [[] for _ in range(N_STATES)]
        duration_state_samples = [[] for _ in range(N_STATES)]

        for path in paths:
            y = load_mono(path)
            mel_db, energy, f0 = frame_features(y)
            n_frames = mel_db.shape[1]
            splits = np.array_split(np.arange(n_frames), N_STATES)
            inventory_rows.append({
                "token": label,
                "file": str(path.relative_to(ROOT)).replace("\\", "/"),
                "frames": n_frames,
                "duration_seconds": len(y) / SR,
            })
            for state, ids in enumerate(splits):
                if len(ids) == 0:
                    ids = np.array([max(0, min(n_frames - 1, state))])
                duration_state_samples[state].append(float(len(ids)))
                for mel_bin in range(N_MELS):
                    mel_state_samples[state][mel_bin].extend(mel_db[mel_bin, ids].tolist())
                voiced_f0 = f0[ids]
                voiced_f0 = voiced_f0[np.isfinite(voiced_f0) & (voiced_f0 > 0)]
                if len(voiced_f0):
                    f0_state_samples[state].extend(voiced_f0.tolist())
                energy_state_samples[state].extend(energy[ids].tolist())

        for state in range(N_STATES):
            for mel_bin in range(N_MELS):
                values = np.asarray(mel_state_samples[state][mel_bin], dtype=np.float32)
                mel_means[token_idx, state, mel_bin] = float(values.mean())
                mel_vars[token_idx, state, mel_bin] = float(values.var() + 1e-4)
            f0_values = np.asarray(f0_state_samples[state], dtype=np.float32)
            energy_values = np.asarray(energy_state_samples[state], dtype=np.float32)
            f0_means[token_idx, state] = float(np.median(f0_values)) if len(f0_values) else 0.0
            f0_vars[token_idx, state] = float(f0_values.var() + 1.0) if len(f0_values) else 1.0
            energy_means[token_idx, state] = float(np.mean(energy_values)) if len(energy_values) else 0.0
            duration_frames[token_idx, state] = max(1.0, float(np.mean(duration_state_samples[state])))
            counts[token_idx, state] = len(duration_state_samples[state])

    # Left-to-right topology: stay in the current state or advance one state.
    transition = np.zeros((N_STATES, N_STATES), dtype=np.float32)
    for state in range(N_STATES - 1):
        transition[state, state] = 0.65
        transition[state, state + 1] = 0.35
    transition[-1, -1] = 1.0

    np.savez_compressed(
        OUT_DIR / "gaussian_hmm_model.npz",
        token_names=np.asarray(token_names),
        mel_means=mel_means,
        mel_vars=mel_vars,
        f0_means=f0_means,
        f0_vars=f0_vars,
        energy_means=energy_means,
        duration_frames=duration_frames,
        transition=transition,
    )
    pd.DataFrame(inventory_rows).to_csv(
        OUT_DIR / "training_inventory.csv", index=False, encoding="utf-8-sig"
    )
    parameter_rows = []
    for token_idx, token in enumerate(token_names):
        for state in range(N_STATES):
            parameter_rows.append({
                "token": token,
                "state": state,
                "mean_f0_hz": float(f0_means[token_idx, state]),
                "mean_energy": float(energy_means[token_idx, state]),
                "mean_duration_frames": float(duration_frames[token_idx, state]),
                "mean_duration_seconds": float(duration_frames[token_idx, state] * HOP / SR),
                "mean_log_mel_db": float(mel_means[token_idx, state].mean()),
            })
    pd.DataFrame(parameter_rows).to_csv(
        OUT_DIR / "gaussian_state_parameters.csv", index=False, encoding="utf-8-sig"
    )
    (OUT_DIR / "transition_matrix.json").write_text(
        json.dumps({
            "initial_state_probabilities": [1.0, 0.0, 0.0, 0.0, 0.0],
            "transition_matrix": transition.tolist(),
        }, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    info = {
        "model_type": "supervised left-to-right Gaussian-emission HMM demonstration",
        "states_per_word": N_STATES,
        "transition_matrix": transition.tolist(),
        "sample_rate_hz": SR,
        "n_mels": N_MELS,
        "n_fft": N_FFT,
        "hop_length": HOP,
        "training_sources": "Two supplied eSpeak-generated WAV candidates per word in lab4_data/units",
        "alignment": "Each word recording divided into five consecutive equal-frame regions (supervised time alignment)",
        "generation": "Text determines word-HMM order; each HMM emits state mean trajectories for mel spectrum, F0 and energy; Griffin-Lim is used for waveform reconstruction",
        "limitation": "Educational small-corpus HMM demo; not a production-quality or Baum-Welch-trained commercial TTS model",
    }
    (OUT_DIR / "hmm_model_info.json").write_text(
        json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Trained HMM demo for {n_tokens} word models from {len(inventory_rows)} WAV files")
    return info


if __name__ == "__main__":
    train()
