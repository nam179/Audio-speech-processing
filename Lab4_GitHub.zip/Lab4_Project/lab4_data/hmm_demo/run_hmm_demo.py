from pathlib import Path
import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .backend import synthesize_hmm, save_tracks
from .train_hmm import train

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "audio_output"
FIG = ROOT / "figures"
HMM = Path(__file__).resolve().parent
TEXT = "Mời khách hàng số 23 đến quầy 5"


def main():
    train()
    y, sr, tracks = synthesize_hmm(TEXT, OUT / "hmm_tts.wav")
    save_tracks(tracks, HMM)

    plt.figure(figsize=(11, 4))
    plt.plot(np.arange(len(tracks["f0"])) * 0.01, tracks["f0"], linewidth=0.9)
    plt.xlabel("Time (seconds)")
    plt.ylabel("F0 (Hz)")
    plt.title("HMM generated F0 trajectory")
    plt.tight_layout()
    plt.savefig(FIG / "07_hmm_f0_trajectory.png", dpi=160)
    plt.close()

    plt.figure(figsize=(11, 4))
    plt.plot(np.arange(len(tracks["spectral"])) * 0.01, tracks["spectral"], linewidth=0.9)
    plt.xlabel("Time (seconds)")
    plt.ylabel("Mean log-mel energy (dB)")
    plt.title("HMM generated spectral trajectory")
    plt.tight_layout()
    plt.savefig(FIG / "08_hmm_spectral_trajectory.png", dpi=160)
    plt.close()

    mel = tracks["mel_spectrogram_db"]
    plt.figure(figsize=(11, 4))
    plt.imshow(mel, origin="lower", aspect="auto", interpolation="nearest",
               extent=[0, mel.shape[1] * 0.01, 0, mel.shape[0]])
    plt.colorbar(label="Log-mel energy (dB)")
    plt.xlabel("Time (seconds)")
    plt.ylabel("Mel bin")
    plt.title("HMM generated mel-spectrogram")
    plt.tight_layout()
    plt.savefig(FIG / "09_hmm_generated_mel.png", dpi=160)
    plt.close()

    summary = {
        "text": TEXT,
        "output": "audio_output/hmm_tts.wav",
        "sample_rate_hz": sr,
        "duration_seconds": len(y) / sr,
        "frame_rate_hz": tracks["frame_rate_hz"],
        "model": tracks["model_type"],
        "states_per_word": 5,
        "parameter_frames": len(tracks["f0"]),
    }
    (HMM / "generation_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
