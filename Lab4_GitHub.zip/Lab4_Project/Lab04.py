from __future__ import annotations

import csv
import json
import math
import re
import time
from pathlib import Path
from typing import Dict, List, Tuple

import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import soundfile as sf

ROOT = Path(__file__).resolve().parent
UNITS_DIR = ROOT / "lab4_data" / "units"
OUTPUT_DIR = ROOT / "audio_output"
FIGURES_DIR = ROOT / "figures"
HMM_DIR = ROOT / "lab4_data" / "hmm_demo"
SR = 16000

DIGIT = {
    "0": "không", "1": "một", "2": "hai", "3": "ba", "4": "bốn",
    "5": "năm", "6": "sáu", "7": "bảy", "8": "tám", "9": "chín"
}

SLUG_TO_LABEL = {
    "moi": "mời", "khach": "khách", "hang": "hàng", "so": "số",
    "khong": "không", "mot": "một", "hai": "hai", "ba": "ba",
    "bon": "bốn", "nam": "năm", "sau": "sáu", "bay": "bảy",
    "tam": "tám", "chin": "chín", "den": "đến", "quay": "quầy"
}

UNITS: Dict[str, List[Path]] = {
    label: sorted(UNITS_DIR.glob(f"{slug}_*.wav"))
    for slug, label in SLUG_TO_LABEL.items()
}

TEST_SENTENCES = [
    "Mời khách hàng số 23 đến quầy 5.",
    "Mời khách số 12 đến quầy 3.",
    "Khách hàng số 45 đến quầy 2."
]


def ensure_dirs() -> None:
    for directory in (OUTPUT_DIR, FIGURES_DIR, HMM_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def normalize_queue_text(text: str) -> List[str]:
    text = text.lower()
    text = re.sub(r"[^\w\sÀ-ỹ]", " ", text, flags=re.UNICODE)
    tokens: List[str] = []
    for token in text.split():
        if token.isdigit():
            tokens.extend(DIGIT[d] for d in token)
        else:
            tokens.append(token)
    return tokens


def load_unit(path: Path) -> np.ndarray:
    audio, sr = sf.read(str(path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != SR:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=SR)
    return np.asarray(audio, dtype=np.float32)


def rms(audio: np.ndarray) -> float:
    if len(audio) == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(audio, dtype=np.float64)) + 1e-12))


def duration(audio: np.ndarray) -> float:
    return float(len(audio) / SR)


def match_rms(audio: np.ndarray, target: float = 0.08) -> np.ndarray:
    if len(audio) == 0:
        return audio.astype(np.float32)
    y = audio * (target / max(rms(audio), 1e-8))
    peak = float(np.max(np.abs(y)))
    if peak > 0.95:
        y = y * (0.95 / peak)
    return y.astype(np.float32)


def create_metadata() -> pd.DataFrame:
    rows = []
    for label, paths in UNITS.items():
        for path in paths:
            audio = load_unit(path)
            rows.append({
                "label": label,
                "speaker": "eSpeak_Vietnamese_synthetic_sample",
                "duration": duration(audio),
                "RMS": rms(audio),
                "sample_rate": SR,
                "channels": 1,
                "file_path": str(path.relative_to(ROOT)).replace("\\", "/")
            })
    df = pd.DataFrame(rows).sort_values(["label", "file_path"])
    df.to_csv(ROOT / "lab4_data" / "metadata.csv", index=False, encoding="utf-8-sig")
    return df


def plot_inventory(metadata: pd.DataFrame) -> None:
    plt.figure(figsize=(8, 4.5))
    plt.hist(metadata["duration"], bins=12, edgecolor="black")
    plt.title("Inventory: duration distribution")
    plt.xlabel("Duration (seconds)")
    plt.ylabel("Number of units")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "01_duration_histogram.png", dpi=160)
    plt.close()

    plt.figure(figsize=(8, 4.5))
    plt.hist(metadata["RMS"], bins=12, edgecolor="black")
    plt.title("Inventory: RMS distribution")
    plt.xlabel("RMS")
    plt.ylabel("Number of units")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "02_rms_histogram.png", dpi=160)
    plt.close()

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    axes[0].hist(metadata["duration"], bins=12, edgecolor="black")
    axes[0].set_title("Unit duration")
    axes[0].set_xlabel("Duration (seconds)")
    axes[0].set_ylabel("Count")
    axes[1].hist(metadata["RMS"], bins=12, edgecolor="black")
    axes[1].set_title("Unit RMS")
    axes[1].set_xlabel("RMS")
    axes[1].set_ylabel("Count")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "01_inventory_combined.png", dpi=160)
    plt.close(fig)


def concat_no_fade(audio_list: List[np.ndarray]) -> np.ndarray:
    if not audio_list:
        return np.array([], dtype=np.float32)
    return np.concatenate([match_rms(x) for x in audio_list]).astype(np.float32)


def crossfade(a: np.ndarray, b: np.ndarray, n: int) -> np.ndarray:
    n = min(int(n), len(a), len(b))
    if n <= 0:
        return np.concatenate([a, b]).astype(np.float32)
    alpha = np.linspace(0.0, 1.0, n, endpoint=True, dtype=np.float32)
    middle = (1.0 - alpha) * a[-n:] + alpha * b[:n]
    return np.concatenate([a[:-n], middle, b[n:]]).astype(np.float32)


def concat_with_crossfade(audio_list: List[np.ndarray], xfade_ms: float) -> np.ndarray:
    if not audio_list:
        return np.array([], dtype=np.float32)
    y = match_rms(audio_list[0])
    overlap = int(SR * xfade_ms / 1000.0)
    for audio in audio_list[1:]:
        y = crossfade(y, match_rms(audio), overlap)
    peak = float(np.max(np.abs(y))) if len(y) else 0.0
    if peak > 0.98:
        y = y * (0.98 / peak)
    return y.astype(np.float32)


def join_cost(a: np.ndarray, b: np.ndarray, ms: float = 25, nfft: int = 512) -> float:
    n = min(int(SR * ms / 1000.0), len(a), len(b))
    if n < 8:
        return float("inf")
    wa = np.hanning(n)
    wb = np.hanning(n)
    A = np.fft.rfft(a[-n:] * wa, n=nfft)
    B = np.fft.rfft(b[:n] * wb, n=nfft)
    La = 20 * np.log10(np.maximum(np.abs(A), 1e-8))
    Lb = 20 * np.log10(np.maximum(np.abs(B), 1e-8))
    return float(np.mean((La - Lb) ** 2))


def candidate_target_cost(audio: np.ndarray, target_d: float, target_r: float,
                          sigma_d: float, sigma_r: float) -> float:
    return ((duration(audio) - target_d) / sigma_d) ** 2 + ((rms(audio) - target_r) / sigma_r) ** 2


def select_units_dp(tokens: List[str], metadata: pd.DataFrame,
                    join_weight: float = 0.0005) -> Tuple[List[np.ndarray], List[int], float, list]:
    candidates: List[List[np.ndarray]] = []
    target_stats = {}
    for token in tokens:
        paths = UNITS.get(token, [])
        if not paths:
            raise ValueError(f"Không có inventory cho token: {token}")
        candidates.append([load_unit(p) for p in paths])
        subset = metadata[metadata["label"] == token]
        target_stats[token] = (
            float(subset["duration"].median()),
            float(subset["RMS"].median())
        )

    all_d = metadata["duration"].to_numpy(dtype=float)
    all_r = metadata["RMS"].to_numpy(dtype=float)
    sigma_d = max(float(np.std(all_d, ddof=1)), 0.04)
    sigma_r = max(float(np.std(all_r, ddof=1)), 0.01)

    dp: List[List[float]] = []
    back: List[List[int]] = []
    first_costs = []
    td, tr = target_stats[tokens[0]]
    for audio in candidates[0]:
        first_costs.append(candidate_target_cost(audio, td, tr, sigma_d, sigma_r))
    dp.append(first_costs)
    back.append([-1] * len(first_costs))

    for j in range(1, len(tokens)):
        current_costs = []
        current_back = []
        td, tr = target_stats[tokens[j]]
        for i, current_audio in enumerate(candidates[j]):
            target = candidate_target_cost(current_audio, td, tr, sigma_d, sigma_r)
            options = [
                dp[j - 1][k] + target + join_weight * join_cost(previous_audio, current_audio)
                for k, previous_audio in enumerate(candidates[j - 1])
            ]
            best_previous = int(np.argmin(options))
            current_costs.append(float(options[best_previous]))
            current_back.append(best_previous)
        dp.append(current_costs)
        back.append(current_back)

    final_idx = int(np.argmin(dp[-1]))
    total_cost = float(dp[-1][final_idx])
    indices = [final_idx]
    for j in range(len(tokens) - 1, 0, -1):
        indices.append(back[j][indices[-1]])
    indices.reverse()
    selected = [candidates[j][idx] for j, idx in enumerate(indices)]

    boundary_rows = []
    for j in range(1, len(tokens)):
        left = selected[j - 1]
        right = selected[j]
        boundary_rows.append({
            "left_token": tokens[j - 1],
            "left_candidate": indices[j - 1] + 1,
            "right_token": tokens[j],
            "right_candidate": indices[j] + 1,
            "selected_join_cost": join_cost(left, right),
            "all_candidate_min_join_cost": min(
                join_cost(a, b) for a in candidates[j - 1] for b in candidates[j]
            )
        })
    return selected, indices, total_cost, boundary_rows


def save_audio(path: Path, audio: np.ndarray) -> None:
    sf.write(str(path), audio, SR, subtype="PCM_16")


def plot_spectrogram_comparison(raw: np.ndarray, best: np.ndarray) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(12, 7))
    for ax, audio, title in [
        (axes[0], raw, "Direct concatenation (0 ms overlap)"),
        (axes[1], best, "Cross-fade concatenation (15 ms overlap)")
    ]:
        D = librosa.stft(audio, n_fft=512, hop_length=128)
        db = librosa.amplitude_to_db(np.abs(D), ref=np.max)
        librosa.display.specshow(db, sr=SR, hop_length=128, x_axis="time", y_axis="hz", ax=ax)
        ax.set_title(title)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "03_spectrogram_before_after.png", dpi=160)
    plt.close()


def plot_boundary_waveforms(raw: np.ndarray, best: np.ndarray,
                            selected: List[np.ndarray], tokens: List[str], xfade_ms: float = 15) -> None:
    boundaries_raw = np.cumsum([len(x) for x in selected])[:-1]
    overlap = int(SR * xfade_ms / 1000.0)
    boundaries_best = np.array([sum(len(x) for x in selected[:i]) - i * overlap for i in range(1, len(selected))])
    count = min(2, len(boundaries_raw))
    fig, axes = plt.subplots(count, 2, figsize=(13, 4 * count))
    if count == 1:
        axes = np.array([axes])
    for row in range(count):
        for col, (audio, boundary, label) in enumerate([
            (raw, int(boundaries_raw[row]), "0 ms"),
            (best, int(boundaries_best[row]), "15 ms")
        ]):
            radius = int(0.06 * SR)
            lo = max(0, boundary - radius)
            hi = min(len(audio), boundary + radius)
            t = np.arange(lo, hi) / SR
            axes[row, col].plot(t, audio[lo:hi], linewidth=0.8)
            axes[row, col].axvline(boundary / SR, linestyle="--")
            axes[row, col].set_title(f"Boundary {row+1}: {tokens[row]} → {tokens[row+1]} ({label})")
            axes[row, col].set_xlabel("Time (s)")
            axes[row, col].set_ylabel("Amplitude")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "04_boundary_waveforms.png", dpi=160)
    plt.close()


def plot_costs(boundary_rows: list, baseline_cost: float, selected_cost: float) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
    axes[0].bar(["Fixed candidate 1", "DP selected"], [baseline_cost, selected_cost])
    axes[0].set_title("Sequence cost comparison")
    axes[0].set_ylabel("Cost (same configured objective)")
    labels = [f"{r['left_token']}→{r['right_token']}" for r in boundary_rows]
    values = [r["selected_join_cost"] for r in boundary_rows]
    axes[1].bar(range(len(values)), values)
    axes[1].set_title("Join cost at selected boundaries")
    axes[1].set_xlabel("Adjacent token pair")
    axes[1].set_ylabel("Spectral join cost")
    axes[1].set_xticks(range(len(labels)))
    axes[1].set_xticklabels(labels, rotation=55, ha="right", fontsize=7)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "05_unit_selection_costs.png", dpi=160)
    plt.close()


def analyze_f0(audio: np.ndarray, label: str) -> np.ndarray:
    f0 = librosa.yin(audio, fmin=70, fmax=400, sr=SR,
                     frame_length=1024, hop_length=160)
    frame_energy = librosa.feature.rms(
        y=audio, frame_length=1024, hop_length=160
    )[0]
    n = min(len(f0), len(frame_energy))
    f0 = f0[:n]
    frame_energy = frame_energy[:n]
    valid = (frame_energy > max(float(frame_energy.max()) * 0.10, 1e-4)) & (f0 <= 300)
    f0 = np.where(valid, f0, np.nan)
    times = librosa.times_like(f0, sr=SR, hop_length=160)
    pd.DataFrame({"time_seconds": times, "f0_hz": f0}).to_csv(
        HMM_DIR / f"{label}_f0_track.csv", index=False
    )
    plt.figure(figsize=(10, 4))
    plt.plot(times, f0, linewidth=1)
    plt.title(f"F0 contour: {label}")
    plt.xlabel("Time (seconds)")
    plt.ylabel("F0 (Hz)")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "06_f0_contour.png", dpi=160)
    plt.close()
    return f0


def experiment_duration_and_pitch(audio: np.ndarray) -> None:
    for rate in (0.8, 1.0, 1.2):
        out = librosa.effects.time_stretch(audio, rate=rate)
        save_audio(OUTPUT_DIR / f"duration_{rate:.1f}x.wav", out)
    for semitones in (-2, 2):
        out = librosa.effects.pitch_shift(audio, sr=SR, n_steps=semitones)
        save_audio(OUTPUT_DIR / f"pitch_{semitones:+d}_semitones.wav", out)


def generate_espeak_reference(text: str, destination: Path) -> float | None:
    """Optional classic eSpeak reference; this is NOT neural TTS."""
    import shutil
    import subprocess
    executable = shutil.which("espeak-ng") or shutil.which("espeak")
    if executable is None:
        return None
    start = time.perf_counter()
    subprocess.run([executable, "-v", "vi", "-s", "155", "-w", str(destination), text],
                   check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    elapsed = time.perf_counter() - start
    x, sr = sf.read(str(destination), dtype="float32")
    if x.ndim > 1:
        x = x.mean(axis=1)
    if sr != SR:
        x = librosa.resample(x, orig_sr=sr, target_sr=SR)
        save_audio(destination, x)
    else:
        sf.write(str(destination), x, sr, subtype="PCM_16")
    return elapsed


def main() -> None:
    ensure_dirs()
    missing = [label for label, paths in UNITS.items() if len(paths) < 2]
    if missing:
        raise FileNotFoundError(
            "Inventory thiếu 2 candidate cho: " + ", ".join(missing)
            + ". Hãy kiểm tra lab4_data/units."
        )

    metadata = create_metadata()
    plot_inventory(metadata)

    main_text = TEST_SENTENCES[0]
    tokens = normalize_queue_text(main_text)
    print("Input:", main_text)
    print("Tokens:", tokens)

    baseline_units = [load_unit(UNITS[token][0]) for token in tokens]
    raw_audio = concat_no_fade(baseline_units)
    save_audio(OUTPUT_DIR / "raw_concat.wav", raw_audio)

    selected, indexes, selected_cost, boundary_rows = select_units_dp(tokens, metadata)
    best_audio = concat_with_crossfade(selected, 15)
    save_audio(OUTPUT_DIR / "best_concat.wav", best_audio)

    for ms in (0, 5, 15, 30):
        result = concat_with_crossfade(selected, ms)
        save_audio(OUTPUT_DIR / f"crossfade_{ms}ms.wav", result)

    pd.DataFrame(boundary_rows).to_csv(OUTPUT_DIR / "join_costs.csv", index=False, encoding="utf-8-sig")

    fixed_cost = 0.0
    for token in tokens:
        audio = load_unit(UNITS[token][0])
        subset = metadata[metadata["label"] == token]
        td, tr = float(subset["duration"].median()), float(subset["RMS"].median())
        fixed_cost += candidate_target_cost(audio, td, tr,
                                            max(float(metadata['duration'].std()), 0.04),
                                            max(float(metadata['RMS'].std()), 0.01))
    fixed_join_sum = 0.0
    for i in range(1, len(baseline_units)):
        boundary_join = join_cost(baseline_units[i-1], baseline_units[i])
        fixed_join_sum += boundary_join
        fixed_cost += 0.0005 * boundary_join
    selected_join_sum = float(sum(row["selected_join_cost"] for row in boundary_rows))

    plot_spectrogram_comparison(raw_audio, best_audio)
    plot_boundary_waveforms(raw_audio, best_audio, selected, tokens)
    plot_costs(boundary_rows, fixed_cost, selected_cost)

    voiced = load_unit(UNITS["mời"][0])
    f0 = analyze_f0(voiced, "moi_01")
    np.save(HMM_DIR / "moi_01_f0.npy", f0)
    # Train and run the five-state left-to-right Gaussian HMM demonstration.
    from lab4_data.hmm_demo.run_hmm_demo import main as run_hmm_demo
    run_hmm_demo()

    experiment_duration_and_pitch(selected[0])

    espeak_rows = []
    for i, sentence in enumerate(TEST_SENTENCES, start=1):
        sentence_tokens = normalize_queue_text(sentence)
        sentence_units = [load_unit(UNITS[token][0]) for token in sentence_tokens]
        audio = concat_with_crossfade(sentence_units, 15)
        save_audio(OUTPUT_DIR / f"test_sentence_{i}_concat.wav", audio)
        elapsed = generate_espeak_reference(
            sentence,
            OUTPUT_DIR / f"test_sentence_{i}_espeak_reference.wav"
        )
        espeak_rows.append({
            "sentence_id": i,
            "text": sentence,
            "token_count": len(sentence_tokens),
            "concat_duration_seconds": duration(audio),
            "espeak_reference_latency_seconds": elapsed,
            "espeak_reference_type": "classic eSpeak; not neural TTS"
        })

    pd.DataFrame(espeak_rows).to_csv(OUTPUT_DIR / "three_sentence_test.csv", index=False, encoding="utf-8-sig")
    ratings = pd.DataFrame(columns=[
        "listener_id", "sentence_id", "method", "intelligibility_correct_0_or_1",
        "naturalness_1_to_5", "continuity_1_to_5", "notes"
    ])
    ratings.to_csv(OUTPUT_DIR / "ratings_template.csv", index=False, encoding="utf-8-sig")

    summary = {
        "main_sentence": main_text,
        "tokens": tokens,
        "inventory_labels": len(UNITS),
        "inventory_candidates": int(len(metadata)),
        "sample_rate_hz": SR,
        "selected_candidate_indices_1_based": [i + 1 for i in indexes],
        "dynamic_programming_total_cost": selected_cost,
        "fixed_candidate_objective_cost": fixed_cost,
        "fixed_candidate_total_join_cost": fixed_join_sum,
        "dynamic_programming_total_join_cost": selected_join_sum,
        "join_cost_reduction_percent": (fixed_join_sum - selected_join_sum) / fixed_join_sum * 100 if fixed_join_sum else 0.0,
        "crossfade_ms_saved_as_best": 15,
        "hmm_backend_status": "five-state left-to-right Gaussian-emission HMM per word trained from 32 synthetic WAV units; mel-parameter generation and Griffin-Lim resynthesis completed",
        "hmm_audio": "audio_output/hmm_tts.wav",
        "neural_tts_status": "optional pretrained VITS wrapper supplied; inference requires downloading facebook/mms-tts-vie and installing requirements-neural.txt",
        "speech_inventory_provenance": "synthetic Vietnamese eSpeak voice samples; not human recordings"
    }
    with open(ROOT / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("\nCompleted.")
    print("Inventory units:", len(metadata))
    print("Selected candidates (1-based):", [i + 1 for i in indexes])
    print("Fixed-candidate objective cost:", round(fixed_cost, 4))
    print("DP objective cost:", round(selected_cost, 4))
    print("Created audio, CSV, HMM demo tracks and figures under:", ROOT)
    print("Important: eSpeak samples are synthetic; HMM is an educational five-state parametric demo; neural VITS inference is optional and needs model download.")


if __name__ == "__main__":
    main()
