# CSE457 – LAB 4: TỔNG HỢP TIẾNG NÓI (TEXT-TO-SPEECH)

**Trường Đại học Thủy Lợi – Khoa Công nghệ thông tin**  
**Học phần:** CSE457 – Xử lý âm thanh và tiếng nói  
**Bài thực hành:** Lab 4 – Tổng hợp tiếng nói

> Trước khi nộp, điền họ tên, mã sinh viên, lớp và giảng viên trong `Bao_cao_Lab4.docx`. Inventory trong repository là giọng eSpeak tổng hợp để kiểm thử, không phải bản ghi người thật. Listening-test scores không được tự điền.

## 1. Nội dung

Repository triển khai pipeline mini TTS theo case study “Thông báo xếp hàng”: chuẩn hóa văn bản, xây dựng inventory word-unit, ghép nối waveform, tính target/join cost, chọn candidate bằng dynamic programming, cross-fade, phân tích F0/duration/pitch, HMM-based parameter generation demo và wrapper Neural TTS VITS.

Câu tổng hợp chính: **“Mời khách hàng số 23 đến quầy 5.”**  
Chuỗi token sau normalization: `mời khách hàng số hai ba đến quầy năm`.

## 2. Đối chiếu yêu cầu Lab

| Mục | Nội dung | Kết quả trong repository |
|---|---|---|
| A | Text normalization, inventory ≥15 units, 2 candidates/unit, metadata, histogram | 16 từ × 2 candidates = 32 WAV; metadata và histogram đã tạo. Nguồn giọng eSpeak tổng hợp. |
| B | Baseline concatenation, `raw_concat.wav`, waveform/spectrogram và biên nối | Đã chạy, có WAV và hình phân tích. |
| C | Target cost, join cost, DP, cross-fade 0/5/15/30 ms | Đã chạy; có `best_concat.wav`, bảng cost và bốn biến thể cross-fade. |
| D | F0, duration/time-stretch, pitch shift ±2 semitone, source–filter | Đã chạy; có file audio và biểu đồ F0. |
| E | HMM state sequence, F0/spectral/duration trajectory, waveform | Có backend Gaussian HMM 5 state/word, trained từ 32 WAV mẫu; tạo trajectory và `hmm_tts.wav` bằng mel inversion + Griffin-Lim. Đây là mô hình học tập quy mô nhỏ với căn chỉnh chia đều theo thời gian, không phải HMM TTS production/MLPG. |
| F | Neural TTS pretrained, mel-spectrogram, latency | Có wrapper VITS, script tải model và script inference ba câu. Chưa chạy trong môi trường đóng gói này vì không có kết nối tải checkpoint; chưa có `neural_tts.wav`. |
| G | Intelligibility, naturalness, continuity, latency; MOS/listening test | Có 3 câu test, audio và `ratings_template.csv`. Cần người nghe đánh giá thực tế; không có điểm giả định. |

**Trạng thái:** Các phần A–E đã có đầu ra chạy được với inventory tổng hợp. Phần F có backend/script, nhưng cần tải model và chạy trên máy có Internet. Phần G đã chuẩn bị dữ liệu đánh giá; cần người nghe điền ratings. Không xem F/G là đã đo xong khi chưa có file kết quả thực.

## 3. Cấu trúc repository

```text
Lab4_Project/
├── Lab04.py
├── Bao_cao_Lab4.docx
├── create_report.py
├── generate_inventory_espeak.py
├── prepare_neural_model.py
├── run_neural_tts.py
├── verify_submission.py
├── requirements.txt
├── requirements-neural.txt
├── README.md
├── GITHUB_UPLOAD.md
├── SUBMISSION_STATUS.md
├── run_summary.json
├── lab4_data/
│   ├── __init__.py
│   ├── metadata.csv
│   ├── inventory_source.json
│   ├── NEURAL_TTS_SETUP.md
│   ├── neural_tts_backend.py
│   ├── units/
│   │   ├── README.md
│   │   └── 32 WAV files (16 words × 2 candidates)
│   └── hmm_demo/
│       ├── train_hmm.py
│       ├── backend.py
│       ├── run_hmm_demo.py
│       ├── gaussian_hmm_model.npz
│       ├── gaussian_state_parameters.csv
│       ├── transition_matrix.json
│       ├── hmm_model_info.json
│       ├── training_inventory.csv
│       ├── generated_trajectory.csv
│       ├── generated_state_durations.csv
│       ├── hmm_state_tracks.csv
│       └── generation_summary.json
├── audio_output/
│   ├── raw_concat.wav
│   ├── best_concat.wav
│   ├── hmm_tts.wav
│   ├── crossfade_*.wav
│   ├── duration_*.wav
│   ├── pitch_*.wav
│   ├── test_sentence_*_concat.wav
│   ├── test_sentence_*_espeak_reference.wav
│   ├── join_costs.csv
│   ├── three_sentence_test.csv
│   └── ratings_template.csv
└── figures/
    ├── 01_inventory_combined.png
    ├── 01_duration_histogram.png
    ├── 02_rms_histogram.png
    ├── 03_spectrogram_before_after.png
    ├── 04_boundary_waveforms.png
    ├── 05_unit_selection_costs.png
    ├── 06_f0_contour.png
    ├── 07_hmm_f0_trajectory.png
    ├── 08_hmm_spectral_trajectory.png
    └── 09_hmm_generated_mel.png
```

## 4. Cài đặt và chạy (Windows / VS Code)

Khuyến nghị Python 3.11–3.13. Mở Terminal trong thư mục chứa `Lab04.py`.

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe Lab04.py
```

Lệnh trên tạo lại metadata, audio concatenation, cross-fade, các thí nghiệm prosody, HMM model/trajectory/audio và biểu đồ. Bộ WAV mẫu đã có sẵn; không cần tạo lại inventory. Để tái tạo 32 WAV bằng eSpeak (cần cài eSpeak và voice tiếng Việt), chạy:

```powershell
.\.venv\Scripts\python.exe generate_inventory_espeak.py
.\.venv\Scripts\python.exe Lab04.py
```

Kiểm tra file và định dạng:

```powershell
.\.venv\Scripts\python.exe verify_submission.py
```

Tạo lại báo cáo sau khi chạy chương trình:

```powershell
.\.venv\Scripts\python.exe create_report.py
```

## 5. Neural TTS (tùy chọn, cần Internet để chuẩn bị model)

Backend dùng checkpoint tiếng Việt `facebook/mms-tts-vie` (kiến trúc VITS). Model card hướng dẫn sử dụng `VitsModel`/`AutoTokenizer` trong Transformers và ghi giấy phép **CC BY-NC 4.0**. Chỉ sử dụng theo đúng điều kiện giấy phép; không dùng cho mục đích thương mại. Xem `lab4_data/NEURAL_TTS_SETUP.md`.

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-neural.txt
.\.venv\Scripts\python.exe prepare_neural_model.py
.\.venv\Scripts\python.exe run_neural_tts.py
```

Khi inference chạy thành công, script tạo `audio_output/neural_tts.wav`, `neural_tts_2.wav`, `neural_tts_3.wav`, `neural_tts_latency.csv` và `figures/10_neural_mel_spectrogram.png`. Model checkpoint không được commit vào GitHub vì dung lượng lớn; thư mục `pretrained_model/` đã được `.gitignore` loại trừ.

## 6. Kết quả hiện có

- `audio_output/raw_concat.wav`: baseline nối trực tiếp.
- `audio_output/best_concat.wav`: candidate từ DP, cross-fade 15 ms.
- `audio_output/hmm_tts.wav`: waveform resynthesis từ HMM-generated log-mel parameters và Griffin-Lim.
- `audio_output/crossfade_0ms.wav`, `crossfade_5ms.wav`, `crossfade_15ms.wav`, `crossfade_30ms.wav`.
- `audio_output/duration_0.8x.wav`, `duration_1.0x.wav`, `duration_1.2x.wav`.
- `audio_output/pitch_-2_semitones.wav`, `audio_output/pitch_+2_semitones.wav`.
- `audio_output/join_costs.csv`, `audio_output/three_sentence_test.csv`, `audio_output/ratings_template.csv`.
- `lab4_data/hmm_demo/`: model, transition matrix, state-duration và frame trajectory CSV.
- `figures/`: thống kê inventory, spectrogram, biên ghép, cost, F0 và HMM trajectories.

Các cost là số đo từ waveform eSpeak mẫu theo công thức được cài đặt; không thể thay cho naturalness MOS. Mẫu `ratings_template.csv` chỉ chứa tiêu đề cột và phải được điền bằng kết quả nghe thật.

## 7. Thông tin sinh viên

- Họ và tên: `[Điền họ tên]`
- Mã sinh viên: `[Điền mã sinh viên]`
- Lớp: `[Điền lớp]`
- Giảng viên: `[Điền tên giảng viên]`

## 8. Tài liệu tham khảo

- Tài liệu giao bài: `Lab 4 – Tổng hợp tiếng nói`, học phần CSE457.
- X. Huang, A. Acero, H.-W. Hon, *Spoken Language Processing*, Prentice Hall, 2001.
- L. R. Rabiner, R. W. Schafer, *Theory and Applications of Digital Speech Processing*, Prentice Hall, 2010.
- Meta, `facebook/mms-tts-vie` model card: https://huggingface.co/facebook/mms-tts-vie.
